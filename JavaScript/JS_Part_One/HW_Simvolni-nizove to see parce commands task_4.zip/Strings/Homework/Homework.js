jsConsole.writeLine('I know that some of these can be done easier with regex, but since we can\'t use them on the exam I\'ve done it the hard way :).');
jsConsole.writeLine();

//Task 1
//Write a JavaScript function reverses string and returns it
//Example: "sample"  "elpmas".
if (!String.prototype.reverse) {
    String.prototype.reverse = function() {
        var result = '';
        for (var i = this.length - 1; i >= 0; i -= 1) {
            result += this[i];
        }
        return result;
    }
}
//Print the test case
jsConsole.writeLine('-----------------Task 1-----------------');
var taskOneTestVar = 'sample';
var reversedVar = taskOneTestVar.reverse();
jsConsole.writeLine('The string is: ' + taskOneTestVar);
jsConsole.writeLine('After "reverse()" the string is: ' + reversedVar);
jsConsole.writeLine();


//Task 2
//Write a JavaScript function to check if in a given expression the brackets are put correctly.
//Example of correct expression: ((a+b)/5-d).
//Example of incorrect expression: )(a+b)).
function checkBrackets(input) {
    var tracker = 0;
    for (var i = 0; i < input.length; i += 1) {
        if (input[i] === '(') {
            tracker += 1;
        } else if (input[i] === ')') {
            tracker -= 1;
        }
        //Without this check ")(a+b))((" will return true
        if (tracker < 0) {
            break;
        }
    };
    if (tracker === 0) {
        return true;
    }
    return false;
}
jsConsole.writeLine('-----------------Task 2-----------------');
jsConsole.writeLine('Checking the first example "((a+b)/5-d)": ' + checkBrackets('((a+b)/5-d)'));
jsConsole.writeLine('Checking the second example ")(a+b))": ' + checkBrackets(')(a+b))'));
jsConsole.writeLine('Checking the second example with addition ")(a+b))((": ' + checkBrackets(')(a+b))(('));
jsConsole.writeLine();


//Task 3
//Write a JavaScript function that finds how many times a substring is contained in a given text (perform case insensitive search).
//Example: The target substring is "in". The text is as follows:
//"We are living in an yellow submarine. We don't have anything else. Inside the submarine is very tight. So we are drinking all the day. We will move out of it in 5 days."
//The result is: 9.
if (!String.prototype.countSubstr) {
    String.prototype.countSubstr = function(sub) {
        var currentPos = 0,
            count = 0;
        while (currentPos >= 0) {
            count += 1;
            currentPos = this.indexOf(sub, currentPos + 1);
        }
        return count;
    }
}
jsConsole.writeLine('-----------------Task 3-----------------');
var exampleText = 'We are living in an yellow submarine. We don\'t have anything else. Inside the submarine is very tight. So we are drinking all the day. We will move out of it in 5 days.';
jsConsole.writeLine('When we check the example we get: ' + exampleText.countSubstr('in'));
jsConsole.writeLine();


//Task 4
//You are given a text. Write a function that changes the text in all regions:
//<upcase>text</upcase> to uppercase.
//<lowcase>text</lowcase> to lowercase
//<mixcase>text</mixcase> to mix casing(random)
//We are <mixcase>living</mixcase> in a <upcase>yellow <mixcase>submarine</mixcase></upcase>. We <mixcase>don't</mixcase> have <lowcase>anything</lowcase> else.
//The expected result: We are LiVinG in a YELLOW SUBMARINE. We dOn'T have anything else.
//Regions can be nested
if (!String.prototype.applyCase) {
    String.prototype.applyCase = function() {
        var operations = [],
            result = '';
        for (var i = 0; i < this.length; i += 1) {
            //Check if a tag is starting
            if (this[i] === '<') {
                i += 1;
                var currentCahr = this[i];
                if (currentCahr !== '/') {
                    //Check if we should start a new operation
                    var command = '';
                    while (currentCahr !== '>') {
                        command += currentCahr;
                        i += 1;
                        currentCahr = this[i];
                    }
                    operations.push(command);

                } else {
                    //If not we should end one
                    while (currentCahr !== '>') {
                        i += 1;
                        currentCahr = this[i];
                    }
                    operations.pop();
                }
                i += 1;
            }
            //Check if we have any operations to perform
            if (operations.length > 0) {
                var operation = operations[operations.length - 1];
                switch (operation) {
                    case 'upcase':
                        result += this[i].toUpperCase();
                        break;
                    case 'lowcase':
                        result += this[i].toLowerCase();
                        break;
                    case 'mixcase':
                        var rand = Math.floor((Math.random() * 10) + 1);
                        if (rand >= 5) {
                            result += this[i].toUpperCase();
                        } else {
                            result += this[i].toLowerCase();
                        }
                        break;
                    default:
                        result += this[i];
                        break;
                }
            } else {
                result += this[i];
            }
        }
        return result;
    }
}
jsConsole.writeLine('-----------------Task 4-----------------');
var originalString = 'We are &lt;mixcase&gt;living&lt;&#47;mixcase&gt; in a &lt;upcase&gt;yellow &lt;mixcase&gt;submarine&lt;&#47;mixcase&gt;&lt;&#47;upcase&gt;. We &lt;mixcase&gt;don\'t&lt;&#47;mixcase&gt; have &lt;lowcase&gt;ANYTHING&lt;&#47;lowcase&gt; else.';
var stringToWorkWith = 'We are <mixcase>living</mixcase> in a <upcase>yellow <mixcase>submarine</mixcase></upcase>. We <mixcase>don\'t</mixcase> have <lowcase>ANYTHING</lowcase> else.';
jsConsole.writeLine('The original string is (I\'v added one nested tag):');
jsConsole.writeLine(originalString);
jsConsole.writeLine('The result is:');
var changedString = stringToWorkWith.applyCase();
jsConsole.writeLine(changedString);
jsConsole.writeLine();


//Task 5
//Write a function that replaces non breaking white-spaces in a text with &nbsp;
String.prototype.splice = function(start, count, stringToInsert) {
    return this.slice(0, start) + stringToInsert + this.slice(start + count);
};
if (!String.prototype.replaceRepeatedChar) {
    String.prototype.replaceRepeatedChar = function(charToReplace) {
        var result = this.valueOf();
        for (var i = 0; i < result.length; i += 1) {
            if (result[i] === charToReplace && result[i + 1] === charToReplace) {
                i += 1;
                while (result[i] === charToReplace) {
                    result = result.splice(i, 1, '&nbsp;');
                    i += 1;
                }
            }
        }
        return result;
    }
}
jsConsole.writeLine('-----------------Task 5-----------------');
var varWithWhiteSpaces = '                kill the idiot            !';
var varWithNoWhiteSpaces = varWithWhiteSpaces.replaceRepeatedChar(' ');
jsConsole.writeLine('Original (the console truncates the excess spaces): ' + varWithWhiteSpaces);
jsConsole.writeLine('After replacing the spaces with "&amp;nbsp;":' + varWithNoWhiteSpaces);
jsConsole.writeLine();


//Task 6
//Write a function that extracts the content of a html page given as text.
//The function should return anything that is in a tag, without the tags:
//<html><head><title>Sample site</title></head><body><div>text<div>more text</div>and more...</div>in body</body></html>
//result: Sample sitetextmore textand more...in body
function extractTextFromHTML(html) {
    var result = '';
    for (var i = 0; i < html.length; i += 1) {
        //Check if a tag is starting
        var currentCahr = html[i];
        if (currentCahr === '<') {
            while (currentCahr !== '>') {
                i += 1;
                currentCahr = html[i];
            }
        } else {
            result += currentCahr;
        }
    }
    return result;
}
jsConsole.writeLine('-----------------Task 6-----------------');
jsConsole.writeLine('We will use the html from task 4');
jsConsole.writeLine(originalString);
var extractedTextFromHtml = extractTextFromHTML(stringToWorkWith);
jsConsole.writeLine('Result: ' + extractedTextFromHtml);
jsConsole.writeLine();


//Task 7
//Write a script that parses an URL address given in the format: [protocol]://[server]/[resource]
//and extracts from it the [protocol], [server] and [resource] elements. Return the elements in a JSON object.
//For example from the URL http://www.devbg.org/forum/index.php the following information should be extracted:
//{protocol: 'http',
//server: 'www.devbg.org', 
//resource: '/forum/index.php'}
function extractElements(input) {
    var endOfProtocol = input.indexOf('://');
    var protocol = input.substring(0, endOfProtocol);
    var endOfServer = input.indexOf('/', endOfProtocol + 3);
    var server = input.substring(endOfProtocol + 3, endOfServer);
    var resource = input.substring(endOfServer, input.length);
    return {
        'protocol': protocol,
        'server': server,
        'resource': resource
    }
}
var sampleURL = 'https://telerikacademy.com/Courses/Courses/Details/173';
var extractFromUrl = extractElements(sampleURL);
jsConsole.writeLine('-----------------Task 7-----------------');
jsConsole.writeLine('We are going to extract the info from url: ');
jsConsole.writeLine(sampleURL);
jsConsole.writeLine('The result is:');
jsConsole.writeLine('{protocol: \'' + extractFromUrl['protocol'] + '\',');
jsConsole.writeLine('server: \'' + extractFromUrl['server'] + '\',');
jsConsole.writeLine('resource: \'' + extractFromUrl['resource'] + '\'}');
jsConsole.writeLine();


//Task 8
//Write a JavaScript function that replaces in a HTML document given as string all the tags <a href="…">…</a>
//with corresponding tags [URL=…]…/URL].
//Sample HTML fragment:
//<p>Please visit <a href="http://academy.telerik. com">our site</a>
//to choose a training course. Also visit <a href="www.devbg.org">our forum</a> to discuss the courses.</p>
//OUTPUT:
//<p>Please visit [URL=http://academy.telerik. com]our site[/URL] to choose a training course.
//Also visit [URL=www.devbg.org]our forum[/URL] to discuss the courses.</p>
function replaceAnchor(html) {
    var result = '';
    var indexOfNextAnchor = html.indexOf('<a href="');
    var indexOfPrevAnchor = 0;
    while (indexOfNextAnchor >= 0) {
        result += html.substring(indexOfPrevAnchor, indexOfNextAnchor);
        indexOfPrevAnchor = html.indexOf('>', indexOfNextAnchor);
        result += '[URL=' + html.substring(indexOfNextAnchor + 9, indexOfPrevAnchor - 1) + ']';
        var closingTagIndex = html.indexOf('</a>', indexOfNextAnchor);
        result += html.substring(indexOfPrevAnchor + 1, closingTagIndex) + '[/URL]';
        indexOfNextAnchor = html.indexOf('<a href="', closingTagIndex);
        indexOfPrevAnchor = closingTagIndex + 4;
    };
    result += html.substring(indexOfPrevAnchor, html.length);
    return result;
}
jsConsole.writeLine('-----------------Task 8-----------------');
var htmlToReplaceOn = '<p>Please visit <a href="http://academy.telerik. com">our site</a> to choose a training course. Also visit <a href="www.devbg.org">our forum</a> to discuss the courses.</p>';
var replacedHtml = replaceAnchor(htmlToReplaceOn);
jsConsole.writeLine('The input is the same as in the example.');
jsConsole.writeLine('Output (since the console truncates the html tag they will not be visible. Please debug to see the full text of the variable :): ' + replacedHtml);
jsConsole.writeLine();


//Task 9
//Write a function for extracting all email addresses from given text.
//All substrings that match the format <identifier>@<host>…<domain> should be recognized as emails.
//Return the emails as array of strings.
//There's no good way to do this so I will even bother trying :)
function extractEmail(input) {
    //A-Z === 65-90
    //a-z === 97-122
    //. === 46
    var nextPosition = input.indexOf('@');
    var emails = [];
    while (nextPosition > 0) {
        var currentChar = input[nextPosition - 1].charCodeAt();
        var currentLetter = input[nextPosition - 1];
        var currentPosition = nextPosition - 1;
        var email = '';
        //First we get the id
        while ((currentChar >= 65 && currentChar <= 90) || (currentChar >= 97 &&
            currentChar <= 122) || currentChar === 46) {
            email = currentLetter + email;
            currentPosition -= 1;
            currentChar = input[currentPosition].charCodeAt();
            currentLetter = input[currentPosition];
        }
        //We add @
        email += '@';
        currentPosition = nextPosition + 1;
        currentChar = input[currentPosition].charCodeAt();
        currentLetter = input[currentPosition];
        //Second we get the host
        while ((currentChar >= 65 && currentChar <= 90) || (currentChar >= 97 && currentChar <= 122)) {
            email = email + currentLetter;
            currentPosition += 1;
            currentChar = input[currentPosition].charCodeAt();
            currentLetter = input[currentPosition];
        }
        //We add the dot
        email += '.';
        currentPosition += 1;
        currentChar = input[currentPosition].charCodeAt();
        currentLetter = input[currentPosition];
        while ((currentChar >= 65 && currentChar <= 90) || (currentChar >= 97 &&
            currentChar <= 122) || currentChar === 46) {
            email = email + currentLetter;
            currentPosition += 1;
            currentChar = input[currentPosition].charCodeAt();
            currentLetter = input[currentPosition];
        }
        emails.push(email);
        nextPosition = input.indexOf('@', currentPosition);
    }
    return emails;
}
jsConsole.writeLine('-----------------Task 9-----------------');
var sampleText = 'Lorem ABBA exe ipsum, dolor sit amet, ABBA consectetuer adipiscing elit, exe sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel jsmith@apache.com illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. lamal Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat testset facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. someone@yahoo.museum Investigationes demonstraverunt bababab lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, jsmith@apache.org anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.';
var emails = extractEmail(sampleText);
jsConsole.writeLine('The text is too big so please have a look at it in the code.');
jsConsole.writeLine('The extracted emails are: ' + emails.join(', '));
jsConsole.writeLine();


//Task 10
//Write a program that extracts from a given text all palindromes, e.g. "ABBA", "lamal", "exe".
if (!String.prototype.extractPalindromes) {
    String.prototype.extractPalindromes = function() {
        var palindromes = [];
        var textToWorkWith = this.valueOf();
        //Remove punctuation
        var nextComma = textToWorkWith.indexOf(',');
        while (nextComma >= 0) {
            textToWorkWith = textToWorkWith.splice(nextComma, 1, '');
            nextComma = textToWorkWith.indexOf(',', nextComma);
        }
        var nextDot = textToWorkWith.indexOf('.');
        while (nextDot >= 0) {
            textToWorkWith = textToWorkWith.splice(nextDot, 1, '');
            nextDot = textToWorkWith.indexOf('.', nextDot);
        }
        var wordsList = textToWorkWith.split(' ');
        for (var wordIndex in wordsList) {
            var word = wordsList[wordIndex];
            var middle = word.length / 2;
            var leftSide, rightSide;
            if (word.length % 2 === 0) {
                middle -= 1;
                leftSide = word.substring(0, middle + 1);
            } else {
                leftSide = word.substring(0, middle);
            }
            rightSide = word.substring(middle + 1, word.length).reverse();
            if (leftSide === rightSide) {
                palindromes.push(word);
            }
        }
        return palindromes;
    }
}

var pal = sampleText.extractPalindromes();
jsConsole.writeLine('-----------------Task 10-----------------');
jsConsole.writeLine('The text is too big so please have a look at it in the code.');
jsConsole.writeLine('The extracted palindormes are: ' + pal.join(', '));
jsConsole.writeLine();


//Task 11
//Write a function that formats a string using placeholders:
//var str = stringFormat('Hello {0}!', 'Peter');
//str = 'Hello Peter!';
//The function should work with up to 30 placeholders and all types
//var frmt = '{0}, {1}, {0} text {2}';
//var str = stringFormat(frmt, 1, 'Pesho', 'Gosho');
//str = '1, Pesho, 1 text Gosho'
function formatString(stringToFormat) {
    var args = arguments;
    var nextPlaceholder = stringToFormat.indexOf('{');
    var endOfNextPlaceholder = stringToFormat.indexOf('}');
    var result = stringToFormat;
    while (nextPlaceholder >= 0) {
        var argumentPos = parseInt(result.substring(nextPlaceholder + 1, endOfNextPlaceholder));
        result = result.splice(nextPlaceholder, (endOfNextPlaceholder - nextPlaceholder + 1), args[argumentPos + 1]);
        nextPlaceholder = result.indexOf('{', endOfNextPlaceholder);
        endOfNextPlaceholder = result.indexOf('}', nextPlaceholder);
    }
    return result;
}

var str = formatString('Hello {0}!', 'Peter');
jsConsole.writeLine('-----------------Task 11-----------------');
jsConsole.writeLine('When we call the function with the examples given we get: ');
jsConsole.writeLine(str);
var frmt = '{0}, {1}, {0} text {2}';
str = formatString(frmt, 1, 'Pesho', 'Gosho');
jsConsole.writeLine(str);
jsConsole.writeLine();


//Task 12
//Write a function that creates a HTML UL using a template for every HTML LI.
//The source of the list should an array of elements. Replace all placeholders marked with –{…}–
//with the value of the corresponding property of the object.
//Example:
//<div data-type="template" id="list-item">
// <strong>-{name}-</strong> <span>-{age}-</span>
//<div>
//var people = [{name: 'Peter', age: 14},…];
//var tmpl = document.getElementById('list-item').innerHtml;
//var peopleList = generateList(people, template);
//peopleList = '<ul><li><strong>Peter</strong> <span>14</span></li><li>…</li>…</ul>'
function formatHTML(propList, stringToFormat) {
    var result = stringToFormat;
    //First we replace the div with the UL
    var indexOfNextDiv = result.indexOf('<div data-type="template" id="list-item">');
    while (indexOfNextDiv >= 0) {
        result = result.splice(indexOfNextDiv, 41, '<ul>');
        var indexOfEndNextDiv = result.indexOf('<div>', indexOfNextDiv);
        result = result.splice(indexOfEndNextDiv, 5, '</ul>');
        indexOfNextDiv = result.indexOf('<div data-type="template" id="list-item">', indexOfEndNextDiv);
    }
    //Than we start LI by LI
    var indexOfNextLi = result.indexOf('<strong>-{');
    var indexOfLi = 0;
    while (indexOfNextLi >= 0) {
        //Get the name of the property
        var indexOfEndOfStrong = result.indexOf('}-</strong>');
        var propName = result.substring(indexOfNextLi + 10, indexOfEndOfStrong);
        //Replace the first prop
        //Add the <li>
        result = result.splice(indexOfNextLi, 21 + propName.length, '<li><stong>' + propList[indexOfLi][propName] + '</strong></li>');
        //Get the name of the second property
        var spanStart = result.indexOf('<span>-{', indexOfEndOfStrong);
        var spanEnd = result.indexOf('}-</span>', spanStart);
        propName = result.substring(spanStart + 8, spanEnd);
        result = result.splice(spanStart, 17 + propName.length, '<li><span>' + propList[indexOfLi][propName] + '</span></li>');
        indexOfNextLi = result.indexOf('<strong>-{', spanEnd);
        indexOfLi += 1;
    }
    return result;
}

var htmlToFormat = '<div data-type="template" id="list-item"><strong>-{name}-</strong> <span>-{age}-</span><div><div data-type="template" id="list-item"><strong>-{name}-</strong> <span>-{age}-</span><div><div data-type="template" id="list-item"><strong>-{name}-</strong> <span>-{age}-</span><div>';
var people = [{
    name: 'Peter',
    age: 14
}, {
    name: 'Ivan',
    age: 21
}, {
    name: 'Petkan',
    age: 18
}];
var formatedHTML = formatHTML(people, htmlToFormat);